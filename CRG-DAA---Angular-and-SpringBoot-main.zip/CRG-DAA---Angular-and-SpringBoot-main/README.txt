# M - ANGULAR + SPRINGBOOT
* **Názov kurzu:** Angular + springboot
* **Predmet:** CRG + DAA
* **Trieda:** III.ročník
* **Discord Link:** https://discord.gg/d9QFsdy7

**Popis:**
> Tento kurz je zameraný primárne na frameworky SpringBoot a Angular. 
> Kedže sa jedná o náročnejšie frameworky vyžadujúcu znalosť TECHNOLÓGII HTML/CSS/JAVASCRIPT, MYSQL a JAVY v prvej polovici kurzu sa budeme venovať práve im.
> V druhej polovici sa pozrieme na zmieňované frameworky a navrhneme si a naprogramujeme vlastnú webovú appku.

#

**Prerequisites**
* Pokročilé programovacie schopnosti (OOP, Návrhové vzory, cleint-server koncept)
* Základy angličtiny
* Logické myslenie
* **Vedieť používať Google**    

**Nástroje ktoré potrebujeme**
* [Visual Studio Code](https://code.visualstudio.com/Download) 
* [WebStorm](https://www.jetbrains.com/webstorm/download/#section=windows) 
* [DataGrip](https://www.jetbrains.com/datagrip/) 
* [HeidySQL](https://www.heidisql.com/)
* [IntelIJ Idea](https://www.jetbrains.com/idea/)

## **Systém Hodnotenia**
